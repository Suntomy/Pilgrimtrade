
/* PILGRIM PRIVATE BRANDING - MANAGED */
(function () {
  if (typeof document === 'undefined') return;

  function addPilgrimBrand() {
    if (!document.body ||
        document.querySelector('.pilgrim-owner-banner')) return;

    const banner = document.createElement('div');
    banner.className = 'pilgrim-owner-banner';

    const title = document.createElement('div');
    title.textContent = 'PILGRIM PRIVATE TRADING PLATFORM';

    const owner = document.createElement('small');
    owner.textContent =
      'Owner: Olawale Abdul-Ganiyu Adeshina | Adegan Global Enterprise';

    const access = document.createElement('small');
    access.textContent = 'Private system — authorized access only';

    banner.append(title, owner, access);
    document.body.prepend(banner);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addPilgrimBrand);
  } else {
    addPilgrimBrand();
  }
  <script>
const matches = GPArchive.find("app.js");
console.log(matches);</script>
<script>const html = await GPArchive.findAndRead("index.html");
console.log(html);</script>
<script>const css = await GPArchive.readText(
  "pilgrim.zip",
  "pilgrim/styles.css"
);</script>
<script>await GPArchive.loadCSS(
  "pilgrim.zip",
  "pilgrim/styles.css"
);</script>
<script>const brand = await GPArchive.findAndRead(
  "pilgrim-private-brand.js"
);</script>
})();
