async function refreshStatus() {
  const backend = document.getElementById('backend');

  try {
    const response = await fetch('/api/brokers');
    if (!response.ok) {
      throw new Error('Backend response ' + response.status);
    }

    const data = await response.json();
    backend.textContent = 'BACKEND ONLINE';

    for (const item of data.brokers || []) {
      const id = item.name === 'HFM' ? 'hfm' : 'pu';
      const status = document.getElementById(id);
      const message = document.getElementById(id + 'msg');

      if (status) {
        status.textContent = item.liveVerified
          ? 'LIVE VERIFIED'
          : 'NOT CONNECTED';
      }

      if (message) {
        message.textContent = item.message || '';
      }
    }

    const updated = document.getElementById('updated');
    if (updated) {
      updated.textContent =
        'Last checked: ' + new Date().toLocaleString();
    }
  } catch (error) {
    backend.textContent = 'BACKEND OFFLINE';

    const updated = document.getElementById('updated');
    if (updated) {
      updated.textContent = 'Could not reach backend: ' + error.message;
    }
  }
}

refreshStatus();
